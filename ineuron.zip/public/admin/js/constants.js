// STATUS
export const status = ["INACTIVE", "ACTIVE", "PENDING"];

export const statusColor = {
    INACTIVE: "red",
    ACTIVE: "blue",
    PENDING: "yellow",
};
